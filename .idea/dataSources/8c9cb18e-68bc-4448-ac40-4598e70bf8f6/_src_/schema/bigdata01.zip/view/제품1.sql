CREATE VIEW `제품1` AS
  SELECT
    `p`.`prodid`   AS `prodid`,
    `p`.`prdmaker` AS `prdmaker`,
    `p`.`stock`    AS `stock`
  FROM `bigdata01`.`products2` `p`