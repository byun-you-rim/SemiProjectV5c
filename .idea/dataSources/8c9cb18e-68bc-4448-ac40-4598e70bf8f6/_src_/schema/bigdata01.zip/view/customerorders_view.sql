CREATE VIEW `customerorders_view` AS
  SELECT
    `c`.`cid`       AS `cid`,
    `c`.`cname`     AS `cname`,
    `c`.`address`   AS `address`,
    `o`.`saleprice` AS `saleprice`
  FROM (`bigdata01`.`Customer1` `c`
    JOIN `bigdata01`.`Orders1` `o`)