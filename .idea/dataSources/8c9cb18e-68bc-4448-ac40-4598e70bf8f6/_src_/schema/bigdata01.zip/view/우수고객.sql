CREATE VIEW `우수고객` AS
  SELECT
    `c`.`userid` AS `userid`,
    `c`.`name`   AS `name`,
    `c`.`age`    AS `age`
  FROM `bigdata01`.`customers2` `c`
  WHERE `c`.`grade` = 'vip'