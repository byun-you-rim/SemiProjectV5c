CREATE VIEW `제품3` AS
  SELECT
    `p`.`prdname`  AS `prdname`,
    `p`.`prdmaker` AS `prdmaker`,
    `p`.`stock`    AS `stock`
  FROM `bigdata01`.`products2` `p`