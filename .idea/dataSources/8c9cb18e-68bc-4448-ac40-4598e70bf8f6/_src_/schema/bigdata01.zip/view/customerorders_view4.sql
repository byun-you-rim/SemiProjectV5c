CREATE VIEW `customerorders_view4` AS
  SELECT
    `c`.`cname` AS `cname`,
    `b`.`price` AS `price`
  FROM ((`bigdata01`.`Customer1` `c`
    JOIN `bigdata01`.`Orders1` `o` ON (`o`.`cid` = `c`.`cid`)) JOIN `bigdata01`.`Book1` `b` ON (`b`.`bid` = `o`.`oid`))
  WHERE `b`.`price` = 20000