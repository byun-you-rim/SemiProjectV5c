CREATE VIEW `상품정보` AS
  SELECT
    `o`.`addr`     AS `이름`,
    `o`.`ordid`    AS `제조업체`,
    `p`.`prodid`   AS `주문번호`,
    `p`.`prdmaker` AS `주문금액`
  FROM (`bigdata01`.`products2` `p`
    JOIN `bigdata01`.`orders2` `o` ON (`p`.`prodid` = `o`.`prodid`))