CREATE VIEW `customerorders_view2` AS
  SELECT
    `o`.`saleprice` AS `saleprice`,
    `c2`.`address`  AS `address`,
    `o`.`orderdate` AS `orderdate`
  FROM (`bigdata01`.`Customer1` `c2`
    JOIN `bigdata01`.`Orders1` `o` ON (`c2`.`cid` = `o`.`cid`))
  WHERE `c2`.`cname` LIKE '박지성'