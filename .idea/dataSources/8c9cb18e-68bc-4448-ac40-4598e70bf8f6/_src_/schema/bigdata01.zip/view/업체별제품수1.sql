CREATE VIEW `업체별제품수1` AS
  SELECT
    `bigdata01`.`products2`.`prdmaker`       AS `업체명`,
    count(`bigdata01`.`products2`.`prdname`) AS `제품수`
  FROM `bigdata01`.`products2`
  GROUP BY `bigdata01`.`products2`.`prdmaker`