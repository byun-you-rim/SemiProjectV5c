CREATE VIEW `주문정보` AS
  SELECT
    `c`.`name`  AS `이름`,
    `c`.`coins` AS `주소`,
    `o`.`addr`  AS `번호`,
    `o`.`ordid` AS `주문금액`
  FROM (`bigdata01`.`customers2` `c`
    JOIN `bigdata01`.`orders2` `o` ON (`o`.`custid` = `c`.`custid`))