CREATE VIEW `업체별제품수` AS
  SELECT
    `bigdata01`.`products2`.`prdmaker`       AS `prdmaker`,
    count(`bigdata01`.`products2`.`prdname`) AS `count(prdname )`
  FROM `bigdata01`.`products2`
  GROUP BY `bigdata01`.`products2`.`prdmaker`