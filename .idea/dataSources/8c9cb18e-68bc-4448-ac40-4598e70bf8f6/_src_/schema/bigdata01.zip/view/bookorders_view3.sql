CREATE VIEW `bookorders_view3` AS
  SELECT
    `b`.`bname`     AS `bname`,
    `o`.`saleprice` AS `saleprice`,
    `o`.`orderdate` AS `orderdate`
  FROM (`bigdata01`.`Book1` `b`
    JOIN `bigdata01`.`Orders1` `o` ON (`b`.`bid` = `o`.`bid`))