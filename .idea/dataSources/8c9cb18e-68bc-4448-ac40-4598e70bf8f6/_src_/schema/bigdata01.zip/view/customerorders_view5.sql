CREATE VIEW `customerorders_view5` AS
  SELECT
    `c`.`cname`     AS `cname`,
    `b`.`bname`     AS `bname`,
    `o`.`orderdate` AS `orderdate`
  FROM ((`bigdata01`.`Customer1` `c`
    JOIN `bigdata01`.`Orders1` `o` ON (`c`.`cid` = `o`.`oid`)) JOIN `bigdata01`.`Book1` `b` ON (`b`.`bid` = `o`.`bid`))